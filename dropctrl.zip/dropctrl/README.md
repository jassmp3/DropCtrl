# DROPCTRL — by Jass

Control where your dropped links land.

DROPCTRL fixes one specific Chromium annoyance: when you drag a link from
outside the browser onto the current window, Chromium always opens it in a
**new tab**, even if you'd rather it replaced the tab you're already on.
DROPCTRL gives you a single 3-way switch to control that.

## Modes

**REPLACE** *(default)*
Drop a link onto the page → the active tab navigates to it. No extra tab.
- Hold **Shift** or **Ctrl** while dropping to override this once and open a
  new tab instead, without touching the switch.

**NEW TAB**
Drop a link onto the page → it opens in a new tab, and your current tab is
left alone.
- Exception: if you drop directly onto an existing tab in the tab strip,
  that tab navigates instead (this is Chromium's own native behavior — see
  "Known limitation" below).

**ASK**
Every supported link drop shows a small floating confirmation:
`Replace the URL` / `Open new tab` / `Cancel`. Cancel truly does nothing —
no tab, no navigation, no history entry.

## Known limitation: drops directly onto the tab strip

The tab strip (the row of tabs at the top of the window) is native browser
UI, not part of any webpage's DOM. Chrome extensions have no API to observe
or intercept drops that land there — this isn't a missing feature of
DROPCTRL, it's outside what any Manifest V3 extension can reach.

In practice this mostly works out:
- In **REPLACE** and **NEW TAB** modes, Chromium's native tab-strip-drop
  behavior (navigate that specific tab) already matches what DROPCTRL wants,
  so nothing extra is needed.
- In **ASK** mode, a drop directly onto the tab strip cannot show the
  confirmation card — Chromium will just navigate that tab immediately,
  natively, before DROPCTRL ever sees it.

Only drops onto the **page/content area** are something DROPCTRL can
actually intercept and control, and that's where all three modes fully work.

## Installing (unpacked)

1. Open `chrome://extensions`.
2. Enable **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Pin the DROPCTRL icon and open the popup to pick a mode.

## Permissions

- `storage` — remembers your selected mode between browser sessions.
- `tabs` — needed to navigate the active tab or open a new one when you drop
  a link (`chrome.tabs.update` / `chrome.tabs.create`).

No `history`, `bookmarks`, `webNavigation`, or `cookies` permissions are
requested — DROPCTRL doesn't need them.

## Privacy

Everything runs locally. DROPCTRL doesn't collect browsing history, doesn't
store dropped URLs beyond the moment it acts on them, and makes no network
requests of any kind. No account, no server, no analytics.

## Notes on scope

Only drops that carry an actual link (`text/uri-list`) and no files are
touched. Ordinary page behavior — file uploads, image drag-reordering,
dragging a link that already lives on the page — is left alone. As a
heuristic for the latter, DROPCTRL treats a drop as "internal" (and leaves
it untouched) if a `dragstart` fired on the same page immediately before it;
this correctly covers drags that start and end on the same page, though a
drag between two different browser tabs is treated as an external drop
since there's no reliable way to distinguish it.

v1.0

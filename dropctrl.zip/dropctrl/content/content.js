// DROPCTRL — content/content.js
//
// WHAT THIS DOES
// ----------------
// Chromium's default behavior: dragging a URL from outside the browser onto
// a webpage opens that URL in a NEW tab, while dragging the same URL onto a
// tab in the tab strip navigates that specific tab in place. DROPCTRL's job
// is to intercept the PAGE-level drop (which a content script legitimately
// can do, since it happens inside the page's own DOM) and redirect it
// according to the user's chosen mode.
//
// WHAT THIS CANNOT DO (documented, not pretended)
// ----------------
// A drop directly onto the browser's tab strip is native browser chrome —
// it is not part of any page's DOM, and Manifest V3 content scripts have no
// API to observe or intercept it. So:
//   - In REPLACE and NEW TAB modes, a tab-strip drop already does exactly
//     what the spec wants by default (Chromium natively navigates that
//     tab) — no code needed, nothing to break.
//   - In ASK mode, a tab-strip drop CANNOT trigger the confirmation UI.
//     Chromium will just navigate the tab immediately, natively. This is a
//     hard platform limitation, not a bug — see the README.
//
// SCOPE OF INTERCEPTION
// ----------------
// Only drops that plausibly carry a dropped/dragged URL are touched
// (dataTransfer has "text/uri-list", and does NOT also carry "Files").
// Ordinary in-page drag/drop — file uploads, image reordering, dragging a
// link that lives on the page itself, rich text editors, etc. — is left
// completely alone. As a heuristic against interfering with in-page link
// drags, if a "dragstart" fired on this same page immediately before the
// drop, we treat it as an internal drag and don't touch it.

(function () {
  let internalDragActive = false;

  document.addEventListener(
    "dragstart",
    () => {
      internalDragActive = true;
    },
    true
  );

  document.addEventListener(
    "dragend",
    () => {
      internalDragActive = false;
    },
    true
  );

  function looksLikeUrlDrag(dataTransfer) {
    if (!dataTransfer) return false;
    const types = Array.from(dataTransfer.types || []);
    if (types.includes("Files")) return false;
    return types.includes("text/uri-list") || types.includes("text/x-moz-url");
  }

  function extractUrl(dataTransfer) {
    const candidates = [
      dataTransfer.getData("text/uri-list"),
      dataTransfer.getData("text/x-moz-url"),
      dataTransfer.getData("text/plain"),
    ];

    for (const raw of candidates) {
      if (!raw) continue;
      // text/uri-list can contain comment lines starting with '#'.
      const firstLine = raw.split(/\r?\n/).find((line) => line && !line.startsWith("#"));
      if (!firstLine) continue;
      const candidate = firstLine.trim();
      try {
        const parsed = new URL(candidate);
        if (["http:", "https:", "ftp:"].includes(parsed.protocol)) {
          return parsed.href;
        }
      } catch {
        // not a valid absolute URL, try the next candidate
      }
    }
    return null;
  }

  document.addEventListener(
    "dragover",
    (event) => {
      if (internalDragActive) return;
      if (looksLikeUrlDrag(event.dataTransfer)) {
        // Required so the "drop" event actually fires instead of the
        // browser showing its native "not droppable" cursor.
        event.preventDefault();
        if (event.dataTransfer) event.dataTransfer.dropEffect = "link";
      }
    },
    true
  );

  document.addEventListener(
    "drop",
    async (event) => {
      if (internalDragActive) return;
      if (!looksLikeUrlDrag(event.dataTransfer)) return;

      const url = extractUrl(event.dataTransfer);
      if (!url) return;

      // We are now committed to handling this drop ourselves — stop
      // Chromium's native "open dropped URL in a new tab" behavior.
      event.preventDefault();

      const mode = await getMode();
      const overrideNewTab = event.shiftKey || event.ctrlKey;

      if (mode === "replace") {
        sendAction(overrideNewTab ? "newtab" : "replace", url);
      } else if (mode === "newtab") {
        sendAction("newtab", url);
      } else if (mode === "ask") {
        const choice = await window.__dropctrlShowAskOverlay(url);
        if (choice === "replace" || choice === "newtab") {
          sendAction(choice, url);
        }
        // "cancel" → do nothing, matches "cancel must really cancel".
      }
    },
    true
  );

  function getMode() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get("dropctrlMode", (result) => {
          resolve(result && result.dropctrlMode ? result.dropctrlMode : "replace");
        });
      } catch {
        resolve("replace");
      }
    });
  }

  function sendAction(action, url) {
    try {
      chrome.runtime.sendMessage({ source: "dropctrl", type: "EXECUTE_ACTION", action, url });
    } catch (err) {
      console.debug("DROPCTRL: failed to send action", err);
    }
  }
})();

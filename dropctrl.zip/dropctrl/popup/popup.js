// DROPCTRL — popup/popup.js

const MODES = ["replace", "newtab", "ask"];

const DESCRIPTIONS = {
  replace: "Drop links onto the page to replace the active tab.",
  newtab: "Drop links onto the page to open them in a new tab.",
  ask: "Choose what happens every time you drop a link.",
};

const TIPS = {
  replace: {
    label: "TIP",
    text: "Need a new tab this time? Hold Shift or Ctrl while dropping.",
  },
  newtab: {
    label: "TIP",
    text: "Drop directly onto a tab to replace that tab instead.",
  },
  ask: {
    label: "TIP",
    text: "Every link drop will ask before opening.",
  },
};

const TECH_NOTES = [
  "Tabs are basically URLs wearing rectangles.",
  "A browser tab is just a very confident document.",
  "Dragging is just moving pixels until JavaScript gets involved.",
  "Chromium has opinions about where you drop things.",
  "Your mouse has entered the drag phase.",
  "URL acquired. Awaiting landing coordinates.",
  "Ctrl is currently pretending to be a shortcut.",
  "Somewhere, a browser event listener is crying.",
  "Tabs reproduce when left unsupervised.",
  "This extension exists because browsers have rules.",
  "The tab strip is sacred ground. We do not trespass.",
  "dataTransfer.getData() is basically a locked mailbox.",
  "Every drop event has main character energy.",
  "preventDefault() is the extension's favorite word.",
  "A URL is just a string with a job to do.",
  "Shift and Ctrl are the same key wearing different hats.",
  "This popup is 312 pixels of pure focus.",
  "Native browser behavior is stubborn. We negotiate.",
  "text/uri-list: the MIME type nobody talks about.",
  "Service workers nap between messages. Don't wake them for nothing.",
  "Manifest V3 said no to background pages. We respected that.",
  "A dragover event is just a very polite question.",
  "Cancel means cancel. No asterisks.",
  "Chrome's tab strip has no DOM. We can't even see it.",
  "Somewhere a bookmark is jealous of how easy this was.",
  "This extension does one thing. That was the whole plan.",
  "External drags don't fire dragstart. That's the tell.",
  "Glassmorphism: because flat UI got boring.",
  "This click sound is synthesized, not sampled. Fancy.",
  "chrome.storage.local remembers so you don't have to.",
  "The orb in the corner is not sentient. Probably.",
  "Every mode has exactly one job. We kept it that way.",
  "A dropped file and a dropped link look nothing alike here.",
  "Tab A didn't ask to be replaced, but here we are.",
  "Neon glow: 12% functional, 88% vibes.",
];

const els = {};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  els.switchEl = document.querySelector(".switch");
  els.indicator = document.getElementById("switchIndicator");
  els.segReplace = document.getElementById("segReplace");
  els.segNewtab = document.getElementById("segNewtab");
  els.segAsk = document.getElementById("segAsk");
  els.description = document.getElementById("modeDescription");
  els.tip = document.getElementById("modeTip");
  els.techNote = document.getElementById("techNote");

  els.segReplace.addEventListener("click", () => handleSegmentClick("replace"));
  els.segNewtab.addEventListener("click", () => handleSegmentClick("newtab"));
  els.segAsk.addEventListener("click", () => handleSegmentClick("ask"));

  const stored = await getStoredMode();
  applyMode(stored, { silent: true });

  renderTechNote();
}

function getStoredMode() {
  return new Promise((resolve) => {
    chrome.storage.local.get("dropctrlMode", (result) => {
      resolve(MODES.includes(result?.dropctrlMode) ? result.dropctrlMode : "replace");
    });
  });
}

function setStoredMode(mode) {
  chrome.storage.local.set({ dropctrlMode: mode });
}

let currentMode = "replace";

function handleSegmentClick(clickedMode) {
  let nextMode;
  if (clickedMode === currentMode) {
    // Clicking the active segment advances the cycle.
    const idx = MODES.indexOf(currentMode);
    nextMode = MODES[(idx + 1) % MODES.length];
  } else {
    nextMode = clickedMode;
  }
  applyMode(nextMode);
}

function applyMode(mode, { silent = false } = {}) {
  currentMode = mode;
  setStoredMode(mode);

  els.switchEl.dataset.mode = mode;
  [els.segReplace, els.segNewtab, els.segAsk].forEach((seg) => {
    seg.setAttribute("aria-checked", String(seg.dataset.mode === mode));
  });

  els.description.textContent = DESCRIPTIONS[mode];

  const tip = TIPS[mode];
  els.tip.innerHTML = tip ? `<strong>${tip.label}</strong>${tip.text}` : "";

  if (!silent) playClick();
}

function renderTechNote() {
  const hour = new Date().getHours();
  const note = TECH_NOTES[hour % TECH_NOTES.length];
  els.techNote.textContent = `TECH NOTE // ${note}`;
}

// ---------- tiny synthesized UI click, no audio file needed ----------
let audioCtx;
function playClick() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const now = audioCtx.currentTime;

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(1400, now);
    osc.frequency.exponentialRampToValueAtTime(600, now + 0.05);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.22, now + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

    osc.connect(gain).connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
  } catch {
    // Audio is a nicety, never a requirement — fail silently.
  }
}

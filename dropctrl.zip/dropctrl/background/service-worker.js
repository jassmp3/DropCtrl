// DROPCTRL — background/service-worker.js
//
// The service worker is intentionally tiny. It does exactly two jobs:
//   1. Set the default mode ("replace") the first time the extension installs.
//   2. Execute the actual tab action (replace / new tab) whenever a content
//      script or the ask-overlay tells it a decision has been made.
//
// It never stores dropped URLs, never talks to a server, and never runs
// background timers or polling.

const DEFAULT_MODE = "replace";

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const existing = await chrome.storage.local.get("dropctrlMode");
    if (!existing.dropctrlMode) {
      await chrome.storage.local.set({ dropctrlMode: DEFAULT_MODE });
    }
  }
});

/**
 * Safely navigate a tab. Fails silently if the tab has since closed or the
 * URL is restricted (chrome://, extension pages, etc.) — DROPCTRL should
 * never crash the service worker over a stale tab or a bad drop.
 */
async function replaceTab(tabId, url) {
  try {
    await chrome.tabs.update(tabId, { url });
  } catch (err) {
    // Tab may have closed, or the URL may be restricted. Fail silently.
    console.debug("DROPCTRL: replaceTab failed", err);
  }
}

async function openNewTab(url, windowId) {
  try {
    await chrome.tabs.create({ url, windowId, active: true });
  } catch (err) {
    console.debug("DROPCTRL: openNewTab failed", err);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.source !== "dropctrl") return;

  (async () => {
    switch (message.type) {
      case "EXECUTE_ACTION": {
        const { action, url } = message;
        const tab = sender.tab;
        if (!tab || !isSupportedUrl(url)) {
          sendResponse({ ok: false });
          return;
        }

        if (action === "replace") {
          await replaceTab(tab.id, url);
        } else if (action === "newtab") {
          await openNewTab(url, tab.windowId);
        }
        // action === "cancel" (or anything else) → do nothing at all.
        sendResponse({ ok: true });
        break;
      }
      default:
        sendResponse({ ok: false });
    }
  })();

  // Keep the message channel open for the async response above.
  return true;
});

function isSupportedUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" || parsed.protocol === "ftp:";
  } catch {
    return false;
  }
}

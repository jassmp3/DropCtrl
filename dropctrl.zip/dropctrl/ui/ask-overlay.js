// DROPCTRL — ui/ask-overlay.js
//
// A tiny, self-contained confirmation UI shown on the page when ASK mode is
// active. It is NOT a browser popup — it's a small floating glass card
// injected into the page's DOM, removed immediately after a choice is made
// (or after it times out with no answer, which counts as Cancel).
//
// Exposes a single global: window.__dropctrlShowAskOverlay(url) -> Promise
// that resolves to "replace" | "newtab" | "cancel".

(function () {
  if (window.__dropctrlShowAskOverlay) return; // don't redefine on re-injection

  const STYLE_ID = "dropctrl-ask-style";

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .dropctrl-ask-root {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        top: 24px;
        right: 24px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, sans-serif;
      }
      .dropctrl-ask-card {
        width: 240px;
        padding: 16px 16px 14px;
        border-radius: 16px;
        background: linear-gradient(180deg, rgba(18,18,26,0.92), rgba(10,10,16,0.94));
        border: 1px solid rgba(255,255,255,0.08);
        box-shadow:
          0 8px 32px rgba(0,0,0,0.55),
          0 0 0 1px rgba(120,140,255,0.06),
          0 0 24px rgba(90,120,255,0.10);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        color: #e8e9f5;
        animation: dropctrl-ask-in 180ms cubic-bezier(.2,.8,.3,1.2);
        transform-origin: top right;
      }
      @keyframes dropctrl-ask-in {
        from { opacity: 0; transform: scale(0.92) translateY(-6px); }
        to   { opacity: 1; transform: scale(1) translateY(0); }
      }
      .dropctrl-ask-eyebrow {
        font-size: 10px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: rgba(160,180,255,0.9);
        margin: 0 0 6px;
        font-weight: 600;
      }
      .dropctrl-ask-title {
        font-size: 13px;
        color: rgba(232,233,245,0.92);
        margin: 0 0 12px;
        line-height: 1.35;
      }
      .dropctrl-ask-url {
        display: block;
        font-size: 11px;
        color: rgba(160,170,210,0.75);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: -8px 0 12px;
      }
      .dropctrl-ask-btn {
        all: unset;
        box-sizing: border-box;
        display: block;
        width: 100%;
        text-align: center;
        padding: 9px 10px;
        margin-top: 8px;
        border-radius: 10px;
        font-size: 12.5px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 90ms ease, filter 120ms ease;
        border: 1px solid rgba(255,255,255,0.08);
      }
      .dropctrl-ask-btn:hover { filter: brightness(1.15); }
      .dropctrl-ask-btn:active { transform: scale(0.97); }
      .dropctrl-ask-btn:focus-visible { outline: 2px solid rgba(140,170,255,0.8); outline-offset: 2px; }
      .dropctrl-ask-btn.replace {
        background: linear-gradient(135deg, rgba(70,130,255,0.28), rgba(70,130,255,0.10));
        color: #cfe0ff;
      }
      .dropctrl-ask-btn.newtab {
        background: linear-gradient(135deg, rgba(150,90,255,0.26), rgba(150,90,255,0.10));
        color: #e2d4ff;
      }
      .dropctrl-ask-btn.cancel {
        background: rgba(255,255,255,0.04);
        color: rgba(230,230,240,0.65);
      }
    `;
    document.documentElement.appendChild(style);
  }

  function truncateUrl(url) {
    return url.length > 46 ? url.slice(0, 43) + "…" : url;
  }

  window.__dropctrlShowAskOverlay = function (url) {
    ensureStyle();

    return new Promise((resolve) => {
      let settled = false;
      const settle = (choice) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(choice);
      };

      const root = document.createElement("div");
      root.className = "dropctrl-ask-root";
      root.innerHTML = `
        <div class="dropctrl-ask-card" role="dialog" aria-label="DROPCTRL drop detected">
          <p class="dropctrl-ask-eyebrow">Drop detected</p>
          <p class="dropctrl-ask-title">What should happen with this link?</p>
          <span class="dropctrl-ask-url"></span>
          <button type="button" class="dropctrl-ask-btn replace">Replace the URL</button>
          <button type="button" class="dropctrl-ask-btn newtab">Open new tab</button>
          <button type="button" class="dropctrl-ask-btn cancel">Cancel</button>
        </div>
      `;
      root.querySelector(".dropctrl-ask-url").textContent = truncateUrl(url);
      document.documentElement.appendChild(root);

      const replaceBtn = root.querySelector(".replace");
      const newtabBtn = root.querySelector(".newtab");
      const cancelBtn = root.querySelector(".cancel");

      replaceBtn.addEventListener("click", () => settle("replace"));
      newtabBtn.addEventListener("click", () => settle("newtab"));
      cancelBtn.addEventListener("click", () => settle("cancel"));

      function onKeydown(e) {
        if (e.key === "Escape") settle("cancel");
      }
      document.addEventListener("keydown", onKeydown, true);

      function onOutsideClick(e) {
        if (!root.contains(e.target)) settle("cancel");
      }
      // Delay attaching so the triggering drop event doesn't instantly close it.
      setTimeout(() => document.addEventListener("mousedown", onOutsideClick, true), 0);

      // Auto-cancel after 20s of no response so a forgotten overlay can't
      // silently block anything or linger forever.
      const timeoutId = setTimeout(() => settle("cancel"), 20000);

      replaceBtn.focus();

      function cleanup() {
        clearTimeout(timeoutId);
        document.removeEventListener("keydown", onKeydown, true);
        document.removeEventListener("mousedown", onOutsideClick, true);
        root.remove();
      }
    });
  };
})();
